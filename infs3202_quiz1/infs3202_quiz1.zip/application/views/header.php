
<div class="card text-center">
  <div class="card-header">
    Title
  </div>
  <div class="card-body">
    <h5 class="card-title">This is your title</h5>
    <p class="card-text">Have a good day</p>
  </div>
</div>