
<div class="container">
	<br>
    <div class="alert alert-primary" role="alert">
    	Click <a href="/infs3202_quiz1/quiz1/task_a" class="alert-link">here</a> to view the page generated in Task A.
    </div>
    <div class="alert alert-secondary" role="alert">
		Click <a href="/infs3202_quiz1/quiz1/task_b" class="alert-link">here</a> to view the page generated in Task B.
    </div>

</div>
