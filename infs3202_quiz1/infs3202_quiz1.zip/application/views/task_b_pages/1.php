
<div class="container">
    <div class="card w-75">
    <div class="card-body">
        <h5 class="card-title">Car 1</h5>
        <p class="card-text">You have successfully loaded the page 1.</p>
        <a href="/infs3202_quiz1/quiz1/details/1" class="btn btn-primary stretched-link">Details</a>
		<pre>
								  @
               (__)    (__) _____/
            /| (oo) _  (oo)/----/_____    *
  _o\______/_|\_\/_/_|__\/|____|//////== *- *  * -
 /_________   \   00 |   00 |       /== -* * -
[_____/^^\_____\_____|_____/^^\_____]     *- * -
      \__/                 \__/
		</pre>
    </div>
    </div>
</div>
