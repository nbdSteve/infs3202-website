
<div class="container">
	<div class="card w-75">
		<div class="card-body">
			<h5 class="card-title">Car 2</h5>
			<p class="card-text">You have successfully loaded the page 2.</p>
			<a href="/infs3202_quiz1/quiz1/details/2" class="btn btn-primary stretched-link">Details</a>
			<pre>
                  .
    __            |\
 __/__\___________| \_
|   ___    |  ,|   ___`-.
|  /   \   |___/  /   \  `-.
|_| (O) |________| (O) |____|
   \___/          \___/
		</pre>
		</div>
	</div>
</div>
