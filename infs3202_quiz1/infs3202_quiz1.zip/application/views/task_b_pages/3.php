
<div class="container">
	<div class="card w-75">
		<div class="card-body">
			<h5 class="card-title">Ambulance 3.</h5>
			<p class="card-text">You have successfully loaded the page 3.</p>
                  <a href="/infs3202_quiz1/quiz1/details/3" class="btn btn-primary stretched-link">Details</a>
			<pre>
   o_______________}o{
   |              |   \
   |    911       |____\_____
   | _____        |    |_o__ |
   [/ ___ \       |   / ___ \|
  []_/.-.\_\______|__/_/.-.\_[]
     |(O)|             |(O)|
      '-'               '-'
---   ---   ---   ---   ---   ---
		</pre>
		</div>
	</div>
</div>
