
<div class="container">
	<hr>
    <div class="card w-75">
    <div class="card-body">
        <h5 class="card-title">This is the specification for car 1.</h5>
        <a href="/infs3202_quiz1/quiz1/task_b/1" class="btn btn-primary stretched-link">Go back</a>
		<pre>
								  @
               (__)    (__) _____/
            /| (oo) _  (oo)/----/_____    *
  _o\______/_|\_\/_/_|__\/|____|//////== *- *  * -
 /_________   \   00 |   00 |       /== -* * -
[_____/^^\_____\_____|_____/^^\_____]     *- * -
      \__/                 \__/
		</pre>
    </div>
    </div>
</div>
