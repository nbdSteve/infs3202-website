
<div class="container">
	<hr>
	<div class="card w-75">
		<div class="card-body">
		<h5 class="card-title">This is the specification for car 2.</h5>
			<a href="/infs3202_quiz1/quiz1/task_b/2" class="btn btn-primary stretched-link">Go back</a>
			<pre>
                  .
    __            |\
 __/__\___________| \_
|   ___    |  ,|   ___`-.
|  /   \   |___/  /   \  `-.
|_| (O) |________| (O) |____|
   \___/          \___/
		</pre>
		</div>
	</div>
</div>
