
<div class="container">
	<hr>
	<div class="card w-75">
		<div class="card-body">
            <h5 class="card-title">This is the specification for car 3.</h5>
                  <a href="/infs3202_quiz1/quiz1/task_b/3" class="btn btn-primary stretched-link">Go back</a>
			<pre>
   o_______________}o{
   |              |   \
   |    911       |____\_____
   | _____        |    |_o__ |
   [/ ___ \       |   / ___ \|
  []_/.-.\_\______|__/_/.-.\_[]
     |(O)|             |(O)|
      '-'               '-'
---   ---   ---   ---   ---   ---
		</pre>
		</div>
	</div>
</div>
